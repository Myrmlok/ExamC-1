﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Exam
{
    public partial class Form2 : Form
    {
        static string path = $@"C";
        static string[] musBadWords = new string[] { "Какашка","Олух","Дурак" };
        int filesSize = 0;
        FileSystemWatcher fileSystemWatcher;
        ManualResetEvent manualResetEvent = new ManualResetEvent(true);
        static bool FileISCorrected = false;
        public Form2()
        {
            InitializeComponent();
            Directory.CreateDirectory(path);
            SetPrograssBarMaximum();
            fileSystemWatcher = new FileSystemWatcher();
            
            fileSystemWatcher.Path = path;
            fileSystemWatcher.Filter = "*.txt";
            fileSystemWatcher.Created += Watcher_Changed;
            fileSystemWatcher.Deleted += Watcher_Changed;
            fileSystemWatcher.EnableRaisingEvents = true;
            fileSystemWatcher.IncludeSubdirectories = true;

        }
        void SetPrograssBarMaximum()
        {
            filesSize = 0;
            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            var musFilesDerectories = directoryInfo.
                EnumerateDirectories("*", SearchOption.AllDirectories)
                .Select(c=>c.GetFiles())
                .Append(directoryInfo.GetFiles());
            
            foreach(var elDirectory in musFilesDerectories)
            {
                foreach(var elFiles in elDirectory)
                {
                    if (elFiles.Length % 1024 == 0)
                    {
                        filesSize += Convert.ToInt32(elFiles.Length / 1024);
                    }
                    else
                    {
                        filesSize += Convert.ToInt32(elFiles.Length / 1024) + 1;
                    }
                }
            }
            progressBar1.Maximum = filesSize;
        }
        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            SetPrograssBarMaximum();

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            button1.Enabled = false;
            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            var musFilesDerectories = directoryInfo.
                EnumerateDirectories("*", SearchOption.AllDirectories)
                .Select(c => c.GetFiles("*.txt"))
                .Append(directoryInfo.GetFiles("*.txt"));
            foreach (var elDirectory in musFilesDerectories)
            {
                foreach (var elFiles in elDirectory)
                {

                    var a = ReadFile(elFiles);
                    await a;
                }
            }
            if (progressBar1.Value == progressBar1.Maximum)
            {
                button1.Enabled = true;
            }
        }
         
        async  Task ReadFile(FileInfo pathFile)
        {
            string result = "";
            using (FileStream fs=new FileStream(pathFile.FullName,FileMode.Open,FileAccess.Read)) 
            {
               
                byte[] buffer = new byte[1024];
                while (true)
                {
                    manualResetEvent.WaitOne();
                    var countByte = await fs.ReadAsync(buffer, 0, buffer.Length);
                    result+=Encoding.UTF8.GetString(buffer, 0, countByte);
                    if (countByte == 0)
                    {
                        break;
                    }
                    progressBar1.Value += 1;
                }
            }
            result = CorrectStrBadWords(result);
            if (FileISCorrected)
            {
                using (FileStream fs = new FileStream(pathFile.Directory.FullName + "/" + "Correct" + pathFile.Name, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    byte[] data = Encoding.UTF8.GetBytes(result);
                    await fs.WriteAsync(data, 0, data.Length);
                }
                FileISCorrected = false;
            }

        } 
        string CorrectStrBadWords(string str)
        {
            string result=str;
            foreach (var el in musBadWords)
            {
                if (str.Contains(el))
                {
                    string Mude = "";
                    for(int i = 0;i < el.Length; i++){
                        Mude += "*";
                    }
                    result= str.Replace(el, Mude);
                    FileISCorrected = true;
                }
            }
            return result;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            manualResetEvent.Reset();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            manualResetEvent.Set();
        }
    }
}
