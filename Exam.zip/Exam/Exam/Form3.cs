﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Exam
{
    public partial class Form3 : Form
    {
        
        [DllImport("user32.dll")]
        public static extern short GetAsyncKeyState(Int32 i);
        public Form3()
        {
            InitializeComponent();
            Timer timer=new Timer();
            timer.Interval = 100;
            timer.Tick += Timer_Tick;
            timer.Start();
            Task.Run(async () => await AddKeys());
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            var mus = Process.GetProcesses();
            foreach (var el in mus)
            {
                listBox1.Items.Add(el.Id+" "+el.ProcessName);
            }
        }

        async Task AddKeys()
        {
            ElementsKeys elementsKeys = new ElementsKeys();
           
            while (true)
            {
               
                await Task.Yield();
                for (int i = 0; i < 255; i++)
                {


                    await Task.Yield();
                    if (GetAsyncKeyState(i) > 0)
                    {
                        elementsKeys.keysElements[i].countkey++;
                       
                    }
                }
               
            }
        }
        
        
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        class KeysElement
        {
            public int key;
            public int countkey;
            public override string ToString()
            {
                return (Keys)key+" Count key: "+countkey;
            }
        }

        private  void button1_Click(object sender, EventArgs e)
        {
        
        }
        class ElementsKeys
        {
            public List<KeysElement> keysElements=new List<KeysElement>();
            public ElementsKeys()
            {
                for (int i = 0; i < 255; i++)
                {
                    keysElements.Add(new KeysElement() { key = i });
                }
            }
            ~ElementsKeys()
            {
                using(FileStream fs=new FileStream("KeysPressed.txt",FileMode.Create,FileAccess.Write))
                {
                    string res = "";
                    foreach (var el in keysElements)
                    {
                        res += el.ToString() + "\n";
                    }
                    byte[] data = Encoding.UTF8.GetBytes(res);
                    fs.Write(data, 0, data.Length);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var processStr= listBox1.SelectedItem as string;
                var id=processStr.Split(' ')[0];
                Process.GetProcessById(Convert.ToInt32( id)).Kill();
                listBox1.Items.Remove(listBox1.SelectedItem);
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

